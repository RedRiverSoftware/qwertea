-- MySQL dump 10.13  Distrib 5.7.12, for Linux (x86_64)
--
-- Host: localhost    Database: qwertea
-- ------------------------------------------------------
-- Server version	5.7.12-0ubuntu1.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `logincodes`
--

DROP TABLE IF EXISTS `logincodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logincodes` (
  `logincode` varchar(255) NOT NULL,
  `forwhom` varchar(255) NOT NULL,
  `expires` int(11) NOT NULL,
  PRIMARY KEY (`forwhom`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logincodes`
--

LOCK TABLES `logincodes` WRITE;
/*!40000 ALTER TABLE `logincodes` DISABLE KEYS */;
INSERT INTO `logincodes` VALUES ('1edf5f1557eaff248d6dd89013955a40','alex',1466805901),('6dfe3827e53afd8acd3d34fe21958f51','jj',1466802415),('27593f540c091e4c508c217dd127da81','williamvenner',1466790981);
/*!40000 ALTER TABLE `logincodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `fromwhom` varchar(255) NOT NULL,
  `guestorder` tinyint(1) NOT NULL,
  `completed` tinyint(1) DEFAULT '0',
  `bywhom` varchar(255) NOT NULL,
  `product` int(11) NOT NULL,
  `extras` text,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `guestallowed` tinyint(1) NOT NULL DEFAULT '1',
  `extras` text,
  `orders` int(11) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('Coffee',1,'coffee.jpg',1,'{\"Milk\":{\"type\":\"boolean\"},\"Sugar\":{\"type\":\"integer\",\"min\":1,\"max\":3}}',0),('Hot Chocolate',2,'hot_chocolate.jpg',1,NULL,0),('Tea',1,'tea.jpg',1,'{\"Milk\":{\"type\":\"boolean\"},\"Sugar\":{\"type\":\"integer\",\"min\":1,\"max\":3}}',0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) NOT NULL,
  `forwhom` varchar(255) NOT NULL,
  `bywhom` varchar(255) NOT NULL,
  `rating` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `constraint` (`orderid`,`forwhom`,`bywhom`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stringvars`
--

DROP TABLE IF EXISTS `stringvars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stringvars` (
  `key_` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key_`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stringvars`
--

LOCK TABLES `stringvars` WRITE;
/*!40000 ALTER TABLE `stringvars` DISABLE KEYS */;
INSERT INTO `stringvars` VALUES ('installed','yes');
/*!40000 ALTER TABLE `stringvars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `slackname` varchar(255) NOT NULL,
  `firstname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `lastname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `allowsms` tinyint(1) NOT NULL DEFAULT '0',
  `avatar` varchar(255) NOT NULL,
  `avatar_large` varchar(255) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '5',
  `is_admin` tinyint(1) NOT NULL,
  `is_owner` tinyint(1) NOT NULL,
  `drinksmade` int(11) NOT NULL DEFAULT '0',
  `drinksdrunk` int(11) NOT NULL DEFAULT '0',
  `logincode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`slackname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('adams','Adam','Sandle','adams@river.red',NULL,0,'https://secure.gravatar.com/avatar/24d249b36702cec4e44f89a8cbfe4a1e.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0013-24.png','https://secure.gravatar.com/avatar/24d249b36702cec4e44f89a8cbfe4a1e.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0013-192.png',5,0,0,0,0,NULL),('alex','Alex','Bowler','sharplybond4@gmail.com','07947521436',0,'https://secure.gravatar.com/avatar/0634367093ed2245e38b0f53b968b77f.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0000-24.png','https://secure.gravatar.com/avatar/0634367093ed2245e38b0f53b968b77f.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0000-192.png',5,0,0,0,0,NULL),('ben',NULL,NULL,'ben@river.red',NULL,0,'https://secure.gravatar.com/avatar/25fcdbb1bb60c81c1d0f6e60302847cc.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F0180%2Fimg%2Favatars%2Fava_0025-24.png','https://secure.gravatar.com/avatar/25fcdbb1bb60c81c1d0f6e60302847cc.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0025-192.png',5,0,0,0,0,NULL),('benkupper','Ben','Kupper','benk@solidstategroup.com',NULL,0,'https://secure.gravatar.com/avatar/f7f328e95c9dc3bc3933e6c55d7a0a6f.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0020-24.png','https://secure.gravatar.com/avatar/f7f328e95c9dc3bc3933e6c55d7a0a6f.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0020-192.png',5,0,0,0,0,NULL),('chrishodges',NULL,NULL,'chris@river.red',NULL,0,'https://secure.gravatar.com/avatar/83a3df53cc9237d1ce8e98003a5c40d1.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0022-24.png','https://secure.gravatar.com/avatar/83a3df53cc9237d1ce8e98003a5c40d1.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0022-192.png',5,0,0,0,0,NULL),('cristina.slack.com','Cristina','Cipollaro','cristina@river.red','07745535476',0,'https://secure.gravatar.com/avatar/cae54b095836e58ca4cf951d19e3b2bc.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0013-24.png','https://secure.gravatar.com/avatar/cae54b095836e58ca4cf951d19e3b2bc.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0013-192.png',5,0,0,0,0,NULL),('danvoyce',NULL,NULL,'dan@signal-noise.co.uk',NULL,0,'https://secure.gravatar.com/avatar/64ffba938b518c06fee85de368fde5f0.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F0180%2Fimg%2Favatars%2Fava_0003-24.png','https://secure.gravatar.com/avatar/64ffba938b518c06fee85de368fde5f0.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0003-192.png',5,0,0,0,0,NULL),('faymarketing','Fay','MacDonald','fay@river.red',NULL,0,'https://secure.gravatar.com/avatar/6bb7552f51380cb43594137e84d04715.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F0180%2Fimg%2Favatars%2Fava_0004-24.png','https://secure.gravatar.com/avatar/6bb7552f51380cb43594137e84d04715.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0004-192.png',5,0,0,0,0,NULL),('fionabugler','Fiona','Bugler','fbugler@amplifylife.com','07733 321 938',0,'https://avatars.slack-edge.com/2016-01-27/19605315253_86a1ff9794a839b05e3f_24.jpg','https://avatars.slack-edge.com/2016-01-27/19605315253_86a1ff9794a839b05e3f_192.jpg',5,0,0,0,0,NULL),('graham','Graham','Cuthbert','graham@river.red',NULL,0,'https://secure.gravatar.com/avatar/9584ad8ecd955ff693cbe567f5b73b0a.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0020-24.png','https://secure.gravatar.com/avatar/9584ad8ecd955ff693cbe567f5b73b0a.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0020-192.png',5,0,0,0,0,NULL),('hayley','Hayley','Price','hayley@river.red','07580012282',0,'https://avatars.slack-edge.com/2016-01-08/18038055744_4d18d24c190e72f9590a_24.jpg','https://avatars.slack-edge.com/2016-01-08/18038055744_4d18d24c190e72f9590a_192.jpg',5,0,0,0,0,NULL),('jakeboud','Jake','Boud','jake@river.red',NULL,0,'https://secure.gravatar.com/avatar/971bf4f602028d7024bf7ba033d5bdd2.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0016-24.png','https://secure.gravatar.com/avatar/971bf4f602028d7024bf7ba033d5bdd2.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0016-192.png',5,0,0,0,0,NULL),('james','James','Seden Smith','james@river.red',NULL,0,'https://secure.gravatar.com/avatar/75a6102e519c90a5531943fea4ab842b.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0012-24.png','https://secure.gravatar.com/avatar/75a6102e519c90a5531943fea4ab842b.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0012-192.png',5,0,0,0,0,NULL),('jawaz','Jawaz','Illavia','jillavia@amplifylife.com','07833059158',0,'https://avatars.slack-edge.com/2015-12-09/16257936981_d48278f4edd637a41a28_24.jpg','https://avatars.slack-edge.com/2015-12-09/16257936981_d48278f4edd637a41a28_192.jpg',5,0,0,0,0,NULL),('jeff','Jeff','Davies','jeff@river.red','07443602212',0,'https://avatars.slack-edge.com/2016-01-06/17872115093_d91e6801e7f285029adb_24.jpg','https://avatars.slack-edge.com/2016-01-06/17872115093_d91e6801e7f285029adb_192.jpg',5,0,0,0,0,NULL),('jj','Jamie','Jarrett','jamiejarrett2000@gmail.com','447449171870',0,'https://secure.gravatar.com/avatar/eca38ad174affab795307fd08fa90eae.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F0180%2Fimg%2Favatars%2Fava_0021-24.png','https://secure.gravatar.com/avatar/eca38ad174affab795307fd08fa90eae.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0021-192.png',5,0,0,1,12,NULL),('johnh','John','Hopkin','john@river.red',NULL,0,'https://secure.gravatar.com/avatar/8d67b7733ec2937d6a64f3be3dd71b81.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0007-24.png','https://secure.gravatar.com/avatar/8d67b7733ec2937d6a64f3be3dd71b81.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0007-192.png',5,0,0,0,0,NULL),('jon','Jon','Hawkins','jon@river.red',NULL,0,'https://avatars.slack-edge.com/2015-04-09/4369980190_8ac3957957dd2d8907c8_24.jpg','https://avatars.slack-edge.com/2015-04-09/4369980190_8ac3957957dd2d8907c8_192.jpg',5,0,0,0,0,NULL),('jonbryant','Jon','Bryant','jbryant@amplifylife.com',NULL,0,'https://avatars.slack-edge.com/2016-04-08/33143283427_53154a9b47f6e51d0a4c_24.jpg','https://avatars.slack-edge.com/2016-04-08/33143283427_53154a9b47f6e51d0a4c_192.jpg',5,0,0,0,0,NULL),('josh',NULL,NULL,'josh@river.red',NULL,0,'https://secure.gravatar.com/avatar/4c423ebc67e18d893c3988bd504d0d29.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F0180%2Fimg%2Favatars%2Fava_0004-24.png','https://secure.gravatar.com/avatar/4c423ebc67e18d893c3988bd504d0d29.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0004-192.png',5,0,0,0,0,NULL),('jpoole',NULL,NULL,'jpoole@amplifylife.com',NULL,0,'https://secure.gravatar.com/avatar/6bd2e748ae19975417651562d24672b7.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0023-24.png','https://secure.gravatar.com/avatar/6bd2e748ae19975417651562d24672b7.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0023-192.png',5,0,0,0,0,NULL),('kierenj','Kieren','Johnstone','k@river.red','07540633435',0,'https://avatars.slack-edge.com/2015-03-24/4168138684_7977901ca251270d7cb9_24.jpg','https://avatars.slack-edge.com/2015-03-24/4168138684_7977901ca251270d7cb9_192.jpg',5,1,1,0,0,NULL),('kyle',NULL,NULL,'kyle@solidstategroup.com',NULL,0,'https://secure.gravatar.com/avatar/c08cb5657df2fe888d98c9e75bb28477.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F0180%2Fimg%2Favatars%2Fava_0025-24.png','https://secure.gravatar.com/avatar/c08cb5657df2fe888d98c9e75bb28477.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0025-192.png',5,0,0,0,0,NULL),('lisal','Lisa','Legg','lisa@river.red',NULL,0,'https://avatars.slack-edge.com/2016-05-21/44812892177_673009db2e7cff1527d9_24.jpg','https://avatars.slack-edge.com/2016-05-21/44812892177_673009db2e7cff1527d9_192.jpg',5,0,0,0,0,NULL),('marinda','Marinda',NULL,'hello@marinda.me',NULL,0,'https://secure.gravatar.com/avatar/13a12aac028b280964c29e5f59b1e1d4.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0016-24.png','https://secure.gravatar.com/avatar/13a12aac028b280964c29e5f59b1e1d4.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0016-192.png',5,0,0,0,0,NULL),('mattelwell',NULL,NULL,'matthewe@solidstategroup.com',NULL,0,'https://secure.gravatar.com/avatar/dab43d8383e8624f69b419f5e1f82e49.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0018-24.png','https://secure.gravatar.com/avatar/dab43d8383e8624f69b419f5e1f82e49.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0018-192.png',5,0,0,0,0,NULL),('niall_q',NULL,NULL,'niall@solidstategroup.com',NULL,0,'https://secure.gravatar.com/avatar/d87695e5af469f12de39bc02dd27a148.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0007-24.png','https://secure.gravatar.com/avatar/d87695e5af469f12de39bc02dd27a148.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0007-192.png',5,0,0,0,0,NULL),('nickjackson','Nick','Jackson','nickj@river.red','07516567820',0,'https://avatars.slack-edge.com/2016-03-01/23824231703_11ea24d142a7fc1df52c_24.jpg','https://avatars.slack-edge.com/2016-03-01/23824231703_11ea24d142a7fc1df52c_192.jpg',5,1,1,0,0,NULL),('nickp','Nicholas','Phillips','nick@river.red',NULL,0,'https://secure.gravatar.com/avatar/8c935b4e73d917e06efebf256145076a.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0000-24.png','https://secure.gravatar.com/avatar/8c935b4e73d917e06efebf256145076a.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0000-192.png',5,0,0,0,0,NULL),('nico','Nico','Blanchot','nico@signal-noise.co.uk','+44 7478743774',0,'https://avatars.slack-edge.com/2015-12-15/16724271076_32d6f21119f9592b1fc5_24.png','https://avatars.slack-edge.com/2015-12-15/16724271076_32d6f21119f9592b1fc5_192.png',5,0,0,0,0,NULL),('pete','Peter','Ross','pete@river.red',NULL,0,'https://secure.gravatar.com/avatar/76834019a5ee921a3a0f534b67870130.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0023-24.png','https://secure.gravatar.com/avatar/76834019a5ee921a3a0f534b67870130.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0023-192.png',5,1,0,0,0,NULL),('qwertea_bot',NULL,NULL,NULL,NULL,0,'https://avatars.slack-edge.com/2016-06-22/53192440916_355acc1c26901a341eb2_24.png','https://avatars.slack-edge.com/2016-06-22/53192440916_355acc1c26901a341eb2_192.png',5,0,0,0,0,NULL),('ricky','Ricky','Stevens','ricky@river.red',NULL,0,'https://secure.gravatar.com/avatar/ff76fb1cb928f6732767a86710a05815.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0007-24.png','https://secure.gravatar.com/avatar/ff76fb1cb928f6732767a86710a05815.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0007-192.png',5,0,0,0,0,NULL),('robyn',NULL,NULL,'robyn@river.red',NULL,0,'https://secure.gravatar.com/avatar/f98c776978fe9732dc887b6dd6c855b0.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0026-24.png','https://secure.gravatar.com/avatar/f98c776978fe9732dc887b6dd6c855b0.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0026-192.png',5,0,0,0,0,NULL),('rsambwani',NULL,NULL,'rsambwani@amplifylife.com',NULL,0,'https://secure.gravatar.com/avatar/9963133ab9222b755612ed0b4b98c512.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0016-24.png','https://secure.gravatar.com/avatar/9963133ab9222b755612ed0b4b98c512.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0016-192.png',5,0,0,0,0,NULL),('sam','Sam','Edwards','sam.edwards@river.red',NULL,0,'https://avatars.slack-edge.com/2016-06-24/54035063858_c3010a8d3d280bb8a274_24.jpg','https://avatars.slack-edge.com/2016-06-24/54035063858_c3010a8d3d280bb8a274_72.jpg',5,0,0,0,0,NULL),('simonpringle','Simon','Pringle','s@river.red',NULL,0,'https://secure.gravatar.com/avatar/9ab1956469836d3c45fcdef7eebfc283.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0006-24.png','https://secure.gravatar.com/avatar/9ab1956469836d3c45fcdef7eebfc283.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0006-192.png',5,1,1,0,0,NULL),('sinead','Sinéad','McCarthy','sinead@signal-noise.co.uk',NULL,0,'https://avatars.slack-edge.com/2016-02-22/22458405141_f030339ad74a3ac9cf31_24.jpg','https://avatars.slack-edge.com/2016-02-22/22458405141_f030339ad74a3ac9cf31_192.jpg',5,0,0,0,0,NULL),('slackbot','slackbot',NULL,NULL,NULL,0,'https://a.slack-edge.com/0180/img/slackbot_24.png','https://a.slack-edge.com/66f9/img/slackbot_192.png',5,0,0,0,0,NULL),('tom',NULL,NULL,'toms@solidstategroup.com',NULL,0,'https://secure.gravatar.com/avatar/6ed63fb9981af431e6fcee2fa200a56f.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0016-24.png','https://secure.gravatar.com/avatar/6ed63fb9981af431e6fcee2fa200a56f.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0016-192.png',5,0,0,0,0,NULL),('wajerrr',NULL,NULL,'wajerrr@gmail.com',NULL,0,'https://secure.gravatar.com/avatar/9ffb19652199e2081b4a899d22852bda.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0000-24.png','https://secure.gravatar.com/avatar/9ffb19652199e2081b4a899d22852bda.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0000-192.png',5,0,0,0,0,NULL),('williamvenner','William','Venner','william@venner.io','+447824098363',0,'https://secure.gravatar.com/avatar/25fa8c3ec5ccc7d49214089e42339170.jpg?s=24&d=https%3A%2F%2Fa.slack-edge.com%2F66f9%2Fimg%2Favatars%2Fava_0002-24.png','https://secure.gravatar.com/avatar/25fa8c3ec5ccc7d49214089e42339170.jpg?s=192&d=https%3A%2F%2Fa.slack-edge.com%2F7fa9%2Fimg%2Favatars%2Fava_0002-192.png',99,0,0,0,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-24 20:44:16
