<?php
	class QwerteaConfig {public function __construct() {$this -> MySQL = new stdClass();

		$this -> MySQL -> Host     = "localhost";
		$this -> MySQL -> Database = "qwertea";
		$this -> MySQL -> User     = "qwertea";
		$this -> MySQL -> Password = "R)y>c5y=?;9'9NSH";

		$this -> SlackURL          = "https://rrsoftware.slack.com/";
		$this -> BotUsername       = "qwertea_bot";

	}};
?>