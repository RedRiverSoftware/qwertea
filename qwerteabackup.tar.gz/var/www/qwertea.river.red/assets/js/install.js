$("#logo").hover(function() {
	$("#radial,#tip").addClass("visible");
}).mouseout(function() {
	$("#radial,#tip").removeClass("visible");
});