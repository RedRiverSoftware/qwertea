<?php
	echo($_SERVER['HTTP_HOST'] . "<br><br>");
	echo($_SERVER['SERVER_NAME']);
?>